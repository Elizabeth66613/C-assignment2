using Cosmetics_Assignment2.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

using Cosmetics_Assignment2.Models;


namespace Cosmetics_Assignment2.Pages
{
	public class CosmeticsModel : PageModel
	{
		// Add the JSON file services:
		// Adding the public service property of type "JsonFileProductService":
		public JsonFileProductService ProductService;

		//getter and setter
		public IEnumerable<Cosmetics>? Cosmetics { get; set; }

		// add the class constructor
		public CosmeticsModel(JsonFileProductService productService)
		{
			ProductService = productService;
		}


		public void OnGet()
		{
            //Calling the product service
            Cosmetics = ProductService.GetCosmetics();
		}

	} // class
}//namespace
