using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Cosmetics_Assignment2.Pages
{
    public class About_usModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
