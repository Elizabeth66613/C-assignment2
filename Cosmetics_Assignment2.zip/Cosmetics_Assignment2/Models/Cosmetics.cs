﻿using System.Text.Json;
using System.Text.Json.Serialization;



namespace Cosmetics_Assignment2.Models
{
    public class Cosmetics
    {
        //getters and setters
        public string? Item { get; set; }

        public string? Color { get; set; }

        [JsonPropertyName("img")]
        public string? Image { get; set; }

        [JsonPropertyName("Face zone")]
        public string? Face_zone { get; set; }
        public string? Description { get; set; }

        /*
        * overriding the ToString() method for every cs class
        * to print a user-friendly message
        */
        // Short version (the arrow) Rocket Ship:
        public override string ToString() => JsonSerializer.Serialize<Cosmetics>(this);


    }//class
}//namespace
