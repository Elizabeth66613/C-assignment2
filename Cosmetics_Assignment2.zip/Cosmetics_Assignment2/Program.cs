using Cosmetics_Assignment2.Services;
using Cosmetics_Assignment2.Models;
using System.Text.Json;

namespace Cosmetics_Assignment2
{
    public class Program
    {
        public static void Main(string[] args)
        {

            // builder has configuration, logging, and many other services added to the DI container
            var builder = WebApplication.CreateBuilder(args);

			// Add services to the container
			builder.Services.AddRazorPages();

			// Adding our services "JsonFileProductService"

			builder.Services.AddTransient<JsonFileProductService>();

			var app = builder.Build();

			// Configure the HTTP request pipeline
			if (!app.Environment.IsDevelopment())
			{
				app.UseExceptionHandler("/Error");
				
				app.UseHsts();
			}

            // Redirects HTTP requests to HTTPS
            app.UseHttpsRedirection();

            // Enables static files, such as HTML, CSS, images, and JavaScript to be served
            app.UseStaticFiles();

            // Adds route matching to the middleware pipeline
            app.UseRouting();

            // Configures endpoint routing for Razor Pages
            app.MapRazorPages();

            //Runs the app
            app.Run();
		}
    }
}
