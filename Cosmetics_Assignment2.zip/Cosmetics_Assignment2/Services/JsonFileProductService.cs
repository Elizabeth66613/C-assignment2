﻿using Microsoft.AspNetCore.Hosting;

using Cosmetics_Assignment2.Models;
using System.Text.Json;


namespace Cosmetics_Assignment2.Services
{
	public class JsonFileProductService
	{
		// constructor
		public JsonFileProductService(IWebHostEnvironment webHostEnvironment)
		{
			WebHostEnvironment = webHostEnvironment;
		}

		// add property of type "IWebHostEnvironment"
		public IWebHostEnvironment WebHostEnvironment { get; }

        // one more property for the "JsonFileName" short version
        private string JsonFileName => Path.Combine(WebHostEnvironment.WebRootPath, "data", "cosmetics.json");


		
		public IEnumerable<Cosmetics> GetCosmetics()
		{
			//Open the text file 
			using var jsonFileReader = File.OpenText(JsonFileName);

			// With JSON Serialize (TO JSON) and Deserialize (FROM JSON)
			/*
            > first parameter: returning an array of type "Product" by reading the JSON file to the end
            > second parameter (optional): for ignoring the upper/lower case

            Using "Deserialize" to return a normal object from the JSON object 
            The new returned object will be an array of products:
             */
			return JsonSerializer.Deserialize<Cosmetics[]>(jsonFileReader.ReadToEnd(),
				new JsonSerializerOptions
				{
					PropertyNameCaseInsensitive = true
				})!;
		}
	} // class
}//namespace
